/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package Constants;

/**
 *
 * @author 20112
 */
public interface FileNames {
    final String TRAINER_FILENAME = "D:\\Software\\OOP_JAVA\\Gym_System\\Gym System\\TestData\\Trainers.txt";
    final String MEMBER_FILENAME = "D:\\Software\\OOP_JAVA\\Gym_System\\Gym System\\TestData\\Members.txt";
    final String CLASS_FILENAME = "D:\\Software\\OOP_JAVA\\Gym_System\\Gym System\\TestData\\Class.txt";
    final String REGISTRATION_FILENAME = "D:\\Software\\OOP_JAVA\\Gym_System\\Gym System\\TestData\\Registrations.txt";
}
